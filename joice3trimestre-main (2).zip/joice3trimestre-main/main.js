function tocaSomPom(){
document.querySelector('som_tecla_pom').play();
}

document.querySelector('.tecla_pom').oniclik=tocaSomPom;


function tocaSomclap(){
    document.querySelector('#som_tecla_pom').play();
}

document.querySelector('.tecla_pom').oniclik = tocaSomclap;

function tocaSomtim() {
    document.querySelector('#som_tecla_TIM).play();
}

function tocaSomtim() {
    document.querySelector('#som_tecla_TIM).play();
}s

function tocaSomPuff() {
    document.querySelector('#som_tecla_Puff).play(); 
}
 
